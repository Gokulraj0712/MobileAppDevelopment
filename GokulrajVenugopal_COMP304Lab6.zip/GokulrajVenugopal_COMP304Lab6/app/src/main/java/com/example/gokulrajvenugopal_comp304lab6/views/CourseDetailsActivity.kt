package com.example.gokulrajvenugopal_comp304lab6.views

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.gokulrajvenugopal_comp304lab6.R
import com.example.gokulrajvenugopal_comp304lab6.database.CollegeDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class CourseDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_details)

        val courseid = intent.getStringExtra("course_id")

       // findViewById<TextView>(R.id.courseDescriptionTextView).text = courseDescription

        println(courseid)
        if (courseid != null) {
            getcoursedescription(courseid.toInt())
        }

    }

    private fun getcoursedescription(courseid: Int) {

        // Get the Course DAO from the database
        val courseDao = CollegeDatabase.getDatabase(this).courseDao()

        // Retrieve the list of course description for the specified course id from the database
        lifecycleScope.launch {
            val desc = withContext(Dispatchers.IO) {
                courseDao.getCourseDescByCourseId(courseid)
            }

            findViewById<TextView>(R.id.courseDescriptionTextView).text = desc.toString()
        }



    }
}
