package com.example.gokulrajvenugopal_comp304lab6.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface CourseDao {

    // Query all courses
    @Query("SELECT * FROM CourseTable")
    fun getAllCourses(): List<CourseEntity>

    // Query a single course by ID
    @Query("SELECT * FROM CourseTable WHERE programId = :programId")
    fun getCourseByProgramId(programId: Int): List<CourseEntity?>

    // Query a single course description by ID
    @Query("SELECT description FROM CourseTable WHERE courseId = :courseId")
    fun getCourseDescByCourseId(courseId: Int): String?

    // Insert a course
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCourse(course: CourseEntity)

    // Insert a list of courses
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCourses(courses: List<CourseEntity>)
}