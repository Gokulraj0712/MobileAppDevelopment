package com.example.gokulrajvenugopal_comp304lab6.views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import com.example.gokulrajvenugopal_comp304lab6.adapter.CourseAdapter
import com.example.gokulrajvenugopal_comp304lab6.database.CourseEntity
import com.example.gokulrajvenugopal_comp304lab6.database.ProgramEntity
import com.example.gokulrajvenugopal_comp304lab6.adapter.ProgramAdapter
import com.example.gokulrajvenugopal_comp304lab6.database.CollegeDatabase
import com.example.gokulrajvenugopal_comp304lab6.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var programAdapter: ProgramAdapter
    private lateinit var courseAdapter: CourseAdapter
    private lateinit var collegeDatabase: CollegeDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        programAdapter = ProgramAdapter(emptyList())
        courseAdapter = CourseAdapter(emptyList())
        collegeDatabase = CollegeDatabase.getDatabase(this)

        // Set the programAdapter to the RecyclerView
        binding.programsRecyclerView.adapter = programAdapter

        addprograms()



    }

    fun addprograms() {

        val program1 =
                    ProgramEntity(1,
                    "ARTIFICIAL INTELLIGENCE - SOFTWARE ENGINEERING TECHNOLOGY",
                    listOf(
                    CourseEntity(
                        1,
                        "AI Ethics and Data Governance",
                        "COMP-261",
                        "This course introduces the ethics of artificial intelligence. Students will explore the ethical principles and frameworks of artificial Intelligence in various areas of life and business, and develop the abilities to analyze ethical issues, solve problems, and make informed decisions. Coursework covers basic ethics concepts, trust and fairness, responsibility and liability, business and ethical risk, psychological concepts, privacy issues, and challenges of applying AI to specific areas.",
                        1),
                    CourseEntity(
                        2,
                        "Natural Language Processing and Recommender Systems",
                        "COMP-262",
                        "The first part of this course focuses on natural language procession concepts and techniques. Topics include sentiment analysis, summarization, dialogue state tracking, etc. Students will apply these concepts to build a conversational interface (chat bot).\n" +
                                "\n" +
                                "The second part of the course introduces recommender systems for predicting user preferences. Topics include the most fundamental techniques used in recommender systems, such as association rules and collaborative filtering. More advanced techniques will be also explained.",
                        1),
                    CourseEntity(
                        3,
                        "Deep Learning",
                        "COMP-263",
                        "This course builds on the artificial neural networks course. Students will be introduced to deep neural networks. Coursework will emphasize convolutional neural networks (CNNs), Sequence Modeling with Recurrent and Recursive Nets, Variational Autoencoders, Deep Generative Models, Representation Learning and Knowledge Transfer, Attention mechanisms and Transformers. Self-supervised learning will also be explored. Students will gain hands-on experience by using Keras and TensorFlow for building and applying deep learning models to image recognition, speech recognition, language translation, and other problems, using real-world datasets.",
                        1),
                        CourseEntity(
                            4,
                            "Cloud Machine Learning",
                            "COMP-264",
                            "In this course, students will be introduced to Cloud AI frameworks. Coursework will emphasize machine learning on AWS, Azure, and Google cloud. Students will gain hands-on experience by building and deploying ML applications using cloud tools and frameworks. Automated machine learning will be also explored.",
                            1),
                        CourseEntity(
                            5,
                            "Software Development Project 2",
                            "COMP-313",
                            "This is a capstone course for Software Engineering Technology, Health Informatics Technology, Artificial Intelligence, Game - Programming programs and builds upon COMP231 Software Development Project 1. The students are required to work in teams to design and implement a complete application or game for a small company. The project must make use of enterprise tools to build enterprise-level data integration. The project must involve teamwork, oral and written communication skills, problem solving, documentation, and research skills. Teams are allowed to select projects that fit with their specialization. Interactive Gaming students will develop a game, and Health Informatics students will select a project that focuses on health care information systems. Students are encouraged to create their teams in the previous semester.",
                            1),
                        CourseEntity(
                            6,
                            "Employment Skills 2",
                            "EMPS-102",
                            "In Employment Skills 2 students will learn the ability to seek career opportunities and effectively market their knowledge, skills and abilities tailored to these opportunities. Students will identify and catalog work and/or voluntary experience, education and skills as employable assets and leverage these to obtain suitable employment that is consistent with their career plans and goals. Students:\n" +
                                    "\n" +
                                    "a) Prepare a Curriculum Vitae (CV)/Resume based on job-research relevant to students’ respective programs\n" +
                                    "\n" +
                                    "b) Use of social media\n" +
                                    "\n" +
                                    "c) Prepare a career portfolio.\n" +
                                    "\n" +
                                    "d) Attend a simulated/mock job interview scenario\n" +
                                    "\n" +
                                    "e) Active assistance of Centennial College Career Services",
                            1),
                        CourseEntity(
                            7,
                            "General Education Elective",
                            "GNED",
                            "Select an elective course from your area of study.",
                            1)


        ))

        val program2 =
                    ProgramEntity(
                        2,
                        "BACHELOR OF INFORMATION TECHNOLOGY",
                        listOf(
                    CourseEntity(
                        8,
                        "Unix/Linux Operating Systems",
                        "NET-211",
                        "This course builds upon topics discussed in Windows Server Operating System. It explores the advanced aspects of the theory, design and application of both single-user and multi-user networks using two competing operating systems: Unix and Linux to support small to large businesses. Unix, an operating system that has great technical merit and stability, and Linux, a free Unix-like operating system that is recognized as a serious competitor for Microsoft Windows Server, are examined from a theoretical perspective and practical aspects such as usage, development and distribution, and file processing. The course will also include the different approaches, methods used to create, operate, configure and troubleshoot network environment and services. Students will explore some of the more popular commands, editors in Linux, file system and security, shell programming etc. and create group /user accounts and set permissions. Learners will also have the opportunity to install and configure the system for FTP, and as a mail server, web server and database server.",
                        2),
                    CourseEntity(
                        9,
                        "Computer and Network Security",
                        "NET-220",
                        "In this course, students are given a clear overview of computer security concepts, including access control, malicious software, cryptography, biometrics as well as government regulations and standards. Various security models, policies and implementation techniques will be explained and evaluated. Students completing this course will have the capability to describe, discuss and design network security using classical and contemporary models. Because of the ever-increasing computer and information attacks on non-profit, commercial, and government computing systems, students will learn how security is an essential part of computer architecture.",
                        2),
                    CourseEntity(
                        10,
                        "Wireless Communication Systems",
                        "NET-221",
                        "This course builds the theoretical foundation for the course sequence NET320 Wireless Networks and the elective sequence, NET902 Cellular Networks and NET903 Wireless Broadband, which examine various wireless networks. It describes the evolution of wireless communication systems and its growing impact on personal communication system, business, health-care and ethical use of social networks. The course provides the theoretical concepts based on Shannon’s Theorem and characteristics of signals in time and frequency domain, noise and its effects in voice and data systems, propagation of electromagnetic waves, modulation schemes and encoding process, using applied mathematics. Various types of antennae and their applications to wireless networks are studied. Transmitters, receivers and their specifications which influence communication systems design are examined for use in wireless networks. The course also introduces major standards for radio communication systems in Canada and worldwide. Application of theory is enhanced through practical lab experiments.",
                        2),
                            CourseEntity(
                                11,
                                "Ethics for a Plural World",
                                "PHL-215",
                                "This course introduces students to core concepts in ethical philosophy with a special emphasis on the challenges of living ethically with others in a cosmopolitan world. The field of ethics is often defined as the study of right and wrong behaviour. However, if we take diversity seriously, what sources do we draw upon to know right from wrong? If we respect the right of different cultures, faiths, peoples and individuals—each with their own unique world view and value system—to exist, than how do we decide what is the ethical way to live? Our world is increasingly becoming interconnected. Global problems like war, human rights abuses and ecological destruction migrate across geographical and political borders. What responsibility do we owe each other in this shared world?",
                                2),
                            CourseEntity(
                                12,
                                "Server-Side Scripting",
                                "SWS-212",
                                "This course introduces students to the more advanced techniques required to build complex, modern database driven applications. Based on previous knowledge of Web design principles, HTML5 and CSS3, this course covers the client-side and server-side processing that enables database interactions in dynamic intranet and Internet applications. Related topics in Web application security, deployment, and maintenance are taught as well. All these concepts will be applied in a group project that implements a fully functional database driven Web application.",
                                2),
                            CourseEntity(
                                13,
                                "Employment Preplacement 1",
                                "WRK-221",
                                "In development.",
                                2)
        ))

        val program3 =
            ProgramEntity(
                3,
                "HEALTH INFORMATICS TECHNOLOGY",
                listOf(
                    CourseEntity(
                        14,
                        "IT Project Management",
                        "CNET-307",
                        "Students are taught the concepts and basic functions of Project Management, and the integration of these concepts and functions into a coherent project management system. Also, role of the project manager and the project management team in implementing and controlling projects. Further, the Project Management Body of Knowledge PMBOK® as defined by the Project Management Institute PMI and its application to Project Management.\n" +
                                "\n" +
                                "CNET307 may be delivered in on-line mode.",
                        3),
                    CourseEntity(
                        15,
                        "Networking for Software Developers",
                        "COMP-216",
                        "Learners in this course will gain hands-on experience by applying knowledge of network protocols and components to the development and maintenance of software applications. Coursework emphasizes network stacks, socket-based network applications, software-defined networks, and developing client applications that interface with various intelligent devices.",
                        3),
                    CourseEntity(
                        16,
                        "Data Structures and Algorithms",
                        "COMP-254",
                        "Building on fundamentals of Object-Oriented programming, this course exposes the students to algorithms and data structures. Students will analyze, evaluate and apply appropriate data structures & algorithms for the implementation of a software system. Coursework emphasizes the classical data structures, basic algorithm design, common operations on data structures, and the use of mathematical techniques to analyze the efficiency of the various algorithms. The languages of instruction are Java and Python (optional).",
                        3),
                    CourseEntity(
                        17,
                        "Business and Entrepreneurship for Software Engineering Technology",
                        "COMP-255",
                        "Software Engineering Technology not only has unlimited potential for transforming the way organizations operate and their decision-making capabilities but, in addition, it provides opportunities for innovation and entrepreneurship. In the latter sense, new ideas are conceived, developed and deployed for the advancement of society. This scenario plays out in so many examples that we see around us. Therefore, the main motivation behind the development of this course is to challenge our software engineering students to increase their knowledge of business processes and to have an entrepreneurial and innovative mindset that can lead to the development of new software products and/or the enhancement of existing ones. The coursework covers business organizational models, processes, ethics, privacy and confidentiality, as well as product development and Entrepreneurship. The topics for the Business component will include organizational structures for large, medium and small businesses with an overview of essential business processes related to manufacturing, retailing, and service industries. Topics for the Product Development and Entrepreneurship component will include software entrepreneurial process, principles of software business ownership, identifying software market opportunity, entrepreneurial software marketing, software business communication and negotiation techniques, feasibility analysis, entrepreneurial financing, legal structures and issues, software business plan development, risk management. The course will promote collaborative teamwork.",
                        3),
                    CourseEntity(
                        18,
                        "Software Development Project 2",
                        "COMP-313",
                        "This is a capstone course for Software Engineering Technology, Health Informatics Technology, Artificial Intelligence, Game - Programming programs and builds upon COMP231 Software Development Project 1. The students are required to work in teams to design and implement a complete application or game for a small company. The project must make use of enterprise tools to build enterprise-level data integration. The project must involve teamwork, oral and written communication skills, problem solving, documentation, and research skills. Teams are allowed to select projects that fit with their specialization. Interactive Gaming students will develop a game, and Health Informatics students will select a project that focuses on health care information systems. Students are encouraged to create their teams in the previous semester.",
                        3),
                    CourseEntity(
                        19,
                        "Enterprise Systems Integration",
                        "COMP-321",
                        "In this course, students will learn the concept of integration as it relates to business processes and information Technology at the Enterprise level. Systems Integration models and concepts of ERPs as cross-functional and process-based systems are demonstrated through software tools such as CRM, SCM, HRM & BI and the Cloud technology. The benefits of these tools are discussed in detail to highlight their effectiveness and efficiency in modern day business operations. UML documentary standards will be adhered to in order to maintain the OO Software Engineering paradigm approach that began in COMP246. Data models are also fundamental requirements. The term projects will center on CRMs and students will engage in the study and walk-through using free download or SaaS of popular ERP Vendor tools such Microsoft Dynamics CRM, Oracle CRM ( Siebel), Salesforce and ZOHO CRM.",
                        3),
                    CourseEntity(
                        20,
                        "Employment Skills 2",
                        "EMPS-102",
                        "In Employment Skills 2 students will learn the ability to seek career opportunities and effectively market their knowledge, skills and abilities tailored to these opportunities. Students will identify and catalog work and/or voluntary experience, education and skills as employable assets and leverage these to obtain suitable employment that is consistent with their career plans and goals. Students:\n" +
                                "\n" +
                                "a) Prepare a Curriculum Vitae (CV)/Resume based on job-research relevant to students’ respective programs\n" +
                                "\n" +
                                "b) Use of social media\n" +
                                "\n" +
                                "c) Prepare a career portfolio.\n" +
                                "\n" +
                                "d) Attend a simulated/mock job interview scenario\n" +
                                "\n" +
                                "e) Active assistance of Centennial College Career Services",
                        3)
                ))
        val program4 =
            ProgramEntity(
                4,
                "GAME – PROGRAMMING",
                listOf(
                    CourseEntity(
                        21,
                        "Special Topics in Interactive Gaming",
                        "COMP-256",
                        "This course will deal with emergent techniques and technologies used in gaming. It could include but not be limited to VR/AR/MR/XR technologies, PBR (Physical Based Rendering) techniques, PCGs (Procedural Content Generation) techniques, current topics in AI in gaming, Machine Learning in Gaming (ml-agents) and more.",
                        4),
                    CourseEntity(
                        22,
                        "Emerging Technologies",
                        "COMP-308",
                        "This course will examine various emerging app development technologies in the rapidly changing world of software. Students will gain hands-on experience by using emerging web development technologies and investigating other emerging trends in software development. Coursework in COMP308 emphasizes emerging patterns and frameworks for full-stack development, emerging architectural styles for APIs, and advancements in artificial intelligence.",
                        4),
                    CourseEntity(
                        23,
                        "Software Development Project 2",
                        "COMP-313",
                        "This is a capstone course for Software Engineering Technology, Health Informatics Technology, Artificial Intelligence, Game - Programming programs and builds upon COMP231 Software Development Project 1. The students are required to work in teams to design and implement a complete application or game for a small company. The project must make use of enterprise tools to build enterprise-level data integration. The project must involve teamwork, oral and written communication skills, problem solving, documentation, and research skills. Teams are allowed to select projects that fit with their specialization. Interactive Gaming students will develop a game, and Health Informatics students will select a project that focuses on health care information systems. Students are encouraged to create their teams in the previous semester.",
                        4),
                    CourseEntity(
                        24,
                        "Advanced Graphics",
                        "COMP-392",
                        "In Advanced Graphics, students learn the core computer graphics concepts that are commonly used in building modern computer games. Different 2D and 3D graphics techniques are explained and applied to building working examples of features that are very popular in today’s fast expanding games industry.\n" +
                                "\n" +
                                "The course includes lectures, demos and discussions of the fundamentals of graphics for game developers, followed by labs and programming assignments that re-enforce the understanding and familiarity of the students with these concepts",
                        4),
                    CourseEntity(
                        25,
                        "Simulation Design",
                        "COMP-395",
                        "This course builds on coursework in COMP391 Introduction to Game and Simulation and COMP305 Game Programming 1. Coursework focuses on fundamental concepts and design principles used for creating computer simulations. Students will explore the design of serious games and simulations by applying game design elements combined with learning theory and instructional design. Topics include designing and building interactive applications and simulations used for educational, training, and modeling purposes in areas of education, business, and health care. The tool used is Unity Engine.",
                        4),
                    CourseEntity(
                        26,
                        "Employment Skills 2",
                        "EMPS-102",
                        "In Employment Skills 2 students will learn the ability to seek career opportunities and effectively market their knowledge, skills and abilities tailored to these opportunities. Students will identify and catalog work and/or voluntary experience, education and skills as employable assets and leverage these to obtain suitable employment that is consistent with their career plans and goals. Students:\n" +
                                "\n" +
                                "a) Prepare a Curriculum Vitae (CV)/Resume based on job-research relevant to students’ respective programs\n" +
                                "\n" +
                                "b) Use of social media\n" +
                                "\n" +
                                "c) Prepare a career portfolio.\n" +
                                "\n" +
                                "d) Attend a simulated/mock job interview scenario\n" +
                                "\n" +
                                "e) Active assistance of Centennial College Career Services",
                        4)
                ))



        GlobalScope.launch(Dispatchers.IO) {

            collegeDatabase.programDao().insertProgramWithSem4Courses(program1)
            collegeDatabase.programDao().insertProgramWithSem4Courses(program2)
            collegeDatabase.programDao().insertProgramWithSem4Courses(program3)
            collegeDatabase.programDao().insertProgramWithSem4Courses(program4)

            collegeDatabase.courseDao().insertCourses(program1.courses)
            collegeDatabase.courseDao().insertCourses(program2.courses)
            collegeDatabase.courseDao().insertCourses(program3.courses)
            collegeDatabase.courseDao().insertCourses(program4.courses)
        }

        programAdapter.setPrograms(listOf(program1, program2,program3 , program4))
       // courseAdapter.setCourses(listOf(program1.courses,program2.courses,program3.courses,program4.courses))


    }

    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setTitle("Exit App")
            .setMessage("Are you sure you want to exit?")
            .setPositiveButton("Yes") { _, _ ->
                // If the user clicks "Yes", exit the app
                finishAffinity()
                exitProcess(0)
            }
            .setNegativeButton("No", null)
            .show()

    }


}