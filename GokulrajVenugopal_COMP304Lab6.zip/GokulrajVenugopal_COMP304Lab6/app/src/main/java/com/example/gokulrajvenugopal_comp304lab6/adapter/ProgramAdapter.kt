package com.example.gokulrajvenugopal_comp304lab6.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gokulrajvenugopal_comp304lab6.database.ProgramEntity
import com.example.gokulrajvenugopal_comp304lab6.databinding.ProgramItemBinding


class ProgramAdapter(private var programs: List<ProgramEntity>) :
    RecyclerView.Adapter<ProgramAdapter.ProgramViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProgramViewHolder {
        val binding = ProgramItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProgramViewHolder(binding, programs)
    }

    override fun onBindViewHolder(holder: ProgramViewHolder, position: Int) {
        val program = programs[position]
        holder.bind(program)
    }

    override fun getItemCount() = programs.size

    fun setPrograms(programs: List<ProgramEntity>) {
        this.programs = programs
        notifyDataSetChanged()
    }

    fun getItem(position: Int): ProgramEntity {
        return programs[position]
    }

    class ProgramViewHolder(private  val binding: ProgramItemBinding, private val programs: List<ProgramEntity>): RecyclerView.ViewHolder(binding.root)
    {
        private val programNameTextView= binding.programNameTextView
        private val coursesRecyclerView: RecyclerView = binding.coursesRecyclerView
        private val courseAdapter: CourseAdapter = CourseAdapter(emptyList())
        private var isExpanded = false

        init {
            programNameTextView.setOnClickListener {
                if (isExpanded) {
                    coursesRecyclerView.visibility = View.GONE
                    isExpanded = false
                } else {
                    coursesRecyclerView.visibility = View.VISIBLE
                    isExpanded = true
                }
            }
        }

        fun bind(program: ProgramEntity) {
            programNameTextView.text = program.name

            coursesRecyclerView.apply {
                layoutManager = LinearLayoutManager(context)
                adapter = courseAdapter
            }

            courseAdapter.setCourses(program.courses)
        }

    }

}