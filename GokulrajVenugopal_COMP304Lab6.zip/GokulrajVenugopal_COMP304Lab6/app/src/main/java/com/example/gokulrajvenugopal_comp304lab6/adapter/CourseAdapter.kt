package com.example.gokulrajvenugopal_comp304lab6.adapter


import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gokulrajvenugopal_comp304lab6.R
import com.example.gokulrajvenugopal_comp304lab6.database.CourseEntity
import com.example.gokulrajvenugopal_comp304lab6.views.CourseDetailsActivity

class CourseAdapter(private var courses: List<CourseEntity>) :
    RecyclerView.Adapter<CourseAdapter.CourseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CourseViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.course_item, parent, false)
        return CourseViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        val course = courses[position]
        holder.bind(course)
    }

    override fun getItemCount() = courses.size

    fun setCourses(courses: List<CourseEntity>) {
        this.courses = courses
        notifyDataSetChanged()
    }

    inner class CourseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

        private val courseCodeTextView: TextView = itemView.findViewById(R.id.courseCodeTextView)
        private val courseNameTextView: TextView = itemView.findViewById(R.id.courseNameTextView)

        fun bind(course: CourseEntity) {
            courseCodeTextView.text = itemView.context.getString(R.string.course_code) + " " +  course.code
            courseNameTextView.text = itemView.context.getString(R.string.course_name) + " " +course.name
        }

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val course = courses[adapterPosition]
            val intent = Intent(itemView.context, CourseDetailsActivity::class.java).apply {
                putExtra("course_id", course.courseId.toString())
                putExtra("course_code", course.code)
                putExtra("course_name", course.name)
                putExtra("course_description", course.description)
            }
            itemView.context.startActivity(intent)
        }
    }
}