package com.example.gokulrajvenugopal_comp304lab6.database

import androidx.room.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


@Entity(tableName = "ProgramTable")
data class ProgramEntity(
    @PrimaryKey val programId : Int?,
    @ColumnInfo(name = "name") val name:String?,
    @TypeConverters(CourseListTypeConverter::class)
    val courses: List<CourseEntity>
)

class CourseListTypeConverter {
    @TypeConverter
    fun fromCourseList(value: List<CourseEntity>): String {
        val gson = Gson()
        val type = object : TypeToken<List<CourseEntity>>() {}.type
        return gson.toJson(value, type)
    }

    @TypeConverter
    fun toCourseList(value: String): List<CourseEntity> {
        val gson = Gson()
        val type = object : TypeToken<List<CourseEntity>>() {}.type
        return gson.fromJson(value, type)
    }
}