package com.example.gokulrajvenugopal_comp304lab6.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query


@Dao
interface ProgramDao {

    // Query all programs and their associated courses for SEM4
    @Query("SELECT * FROM ProgramTable")
    fun getAllProgramsWithSem4Courses(): List<ProgramEntity>

    // Query a single program by name and its associated courses for SEM4
    @Query("SELECT * FROM ProgramTable WHERE name = :programName")
    fun getProgramByNameWithSem4Courses(programName: String): ProgramEntity?

    // Insert a program and its associated courses for SEM4
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertProgramWithSem4Courses(program: ProgramEntity)

    // Insert a list of courses
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCourses(courses: List<CourseEntity>)
}