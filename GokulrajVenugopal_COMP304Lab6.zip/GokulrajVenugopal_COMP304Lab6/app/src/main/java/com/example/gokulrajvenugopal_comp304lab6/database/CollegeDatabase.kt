package com.example.gokulrajvenugopal_comp304lab6.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters


@Database(entities = [ProgramEntity::class, CourseEntity::class], version = 1)
@TypeConverters(CourseListTypeConverter::class)
abstract class CollegeDatabase : RoomDatabase() {

    abstract fun programDao(): ProgramDao
    abstract fun courseDao(): CourseDao

    companion object {
        @Volatile
        private var INSTANCE: CollegeDatabase? = null

        fun getDatabase(context: Context): CollegeDatabase {
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CollegeDatabase::class.java,
                    "app_database"
                ).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}
