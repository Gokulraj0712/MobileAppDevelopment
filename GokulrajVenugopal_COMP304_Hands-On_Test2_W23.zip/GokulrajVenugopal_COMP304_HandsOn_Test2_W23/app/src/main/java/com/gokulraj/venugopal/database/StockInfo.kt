package com.gokulraj.venugopal.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "StockInfo")
data class StockInfo (
        @PrimaryKey val stockSymbol: String,
        @ColumnInfo(name = "companyName") val companyName: String,
        @ColumnInfo(name = "stockQuote") val stockQuote:Double
        )



/*
val stockSymbol: String //primary key
val companyName: String
val stockQuote: Double

*/