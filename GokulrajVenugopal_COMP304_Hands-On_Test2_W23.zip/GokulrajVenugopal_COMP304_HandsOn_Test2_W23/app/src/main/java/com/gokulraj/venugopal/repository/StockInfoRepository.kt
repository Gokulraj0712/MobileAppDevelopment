package com.gokulraj.venugopal.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.gokulraj.venugopal.database.StockInfo
import com.gokulraj.venugopal.database.StockInfoDao

class StockInfoRepository(private val stockInfoDao: StockInfoDao) {

    suspend fun getAllStockInfo(): List<StockInfo> {
        return stockInfoDao.getAllStocks()
    }

    suspend fun getStockSymbol(): List<String> {
        return stockInfoDao.getStockSymbol()
    }

    suspend fun getStockInfo(symbol: String): StockInfo {
        return stockInfoDao.getStockInfo(symbol)

    }

    suspend fun insertStockInfo(stockInfo: StockInfo) {
        stockInfoDao.insertStockInfo(stockInfo)
    }

}