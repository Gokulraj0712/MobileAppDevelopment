package com.gokulraj.venugopal.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query


@Dao
interface StockInfoDao {

    // Query all stocks
    @Query("SELECT * FROM StockInfo")
    fun getAllStocks(): List<StockInfo>

    @Query("SELECT * FROM StockInfo WHERE stockSymbol = :symbol")
    suspend fun getStockInfo(symbol: String): StockInfo

    @Query("SELECT stockSymbol FROM StockInfo ORDER BY rowid ASC")
    suspend fun getStockSymbol(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockInfo(stockInfo: StockInfo)



}