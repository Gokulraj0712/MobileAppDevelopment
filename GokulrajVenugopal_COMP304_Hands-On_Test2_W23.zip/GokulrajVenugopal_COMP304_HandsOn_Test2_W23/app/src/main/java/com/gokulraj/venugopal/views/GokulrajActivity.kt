package com.gokulraj.venugopal.views

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.gokulraj.venugopal.R
import com.gokulraj.venugopal.broadcaster.StockBroadcastReceiver
import com.gokulraj.venugopal.database.StockInfo
import com.gokulraj.venugopal.databinding.ActivityMainBinding
import com.gokulraj.venugopal.viewModel.StockInfoViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.system.exitProcess


class GokulrajActivity : AppCompatActivity() {

    private lateinit var mViewModel: StockInfoViewModel
    private lateinit var txtStockInfoTextView: TextView
    private lateinit var binding: ActivityMainBinding
    private var stock_selected: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mViewModel = ViewModelProvider(this).get(StockInfoViewModel::class.java)
        txtStockInfoTextView = findViewById(R.id.stockInfoTextView)


        binding.insertStocksButton.setOnClickListener{
            insertStocks()
        }

        binding.displayStockInfoButton.setOnClickListener{
            displayStocks()
        }

    }


    @SuppressLint("SetTextI18n")
    private fun displayStocks() {
        val group = findViewById<RadioGroup>(R.id.stockRadioGroup)
        val selectedRadioButton = group.findViewById<RadioButton>(group.checkedRadioButtonId)
        stock_selected = selectedRadioButton?.text.toString()

        GlobalScope.launch{
            val stockInfo = mViewModel.getStockInfo(stock_selected!!)
            withContext(Dispatchers.Main) {
                if (stockInfo != null) {

                    // Print the stock info to the console
                    println("Stock Info: ${stockInfo.companyName}, ${stockInfo.stockQuote}")

                    // Update the UI with the stock info
                    txtStockInfoTextView.text = "Company Name: " + stockInfo.companyName.toString() +
                            "\n" + "Stock Quote: " + stockInfo.stockQuote.toString()

                    val StockName = stockInfo.companyName
                    val StockQuote=stockInfo.stockQuote.toString()

                    val intent = Intent(this@GokulrajActivity, StockBroadcastReceiver::class.java)
                    intent.putExtra(
                        "STOCK_INFO",
                        "Stock Info received:\nCompany name: $StockName\nStock Quote: $StockQuote"
                    )
                    sendBroadcast(intent)
                }
            }
        }
    }




    private fun insertStocks() {
        val stock1 = StockInfo("GOOGL", "Google", 123.51)
        mViewModel.insertStockInfo(stock1)
        val stock2 = StockInfo("AMZN", "Amazon", 990.0)
        mViewModel.insertStockInfo(stock2)
        val stock3 = StockInfo("SSNLF", "Samsung Electronics", 421.87)
        mViewModel.insertStockInfo(stock3)
        val stock4 = StockInfo("MSFT", "Microsoft Corporation", 211.98)
        mViewModel.insertStockInfo(stock4)
        val stock5 = StockInfo("TSLA", "Tesla Inc", 621.87)
        mViewModel.insertStockInfo(stock5)

        Toast.makeText(this, "Stocks are inserted", Toast.LENGTH_SHORT).show()

        val group = findViewById<RadioGroup>(R.id.stockRadioGroup)

    GlobalScope.launch {
        val symbolList = mViewModel.getSymbol()

        withContext(Dispatchers.Main) {

            // Remove existing radio buttons if any
            group.removeAllViews()

            // Create radio button for each symbol
            for (symbol in symbolList) {
                val radioButton = RadioButton(this@GokulrajActivity)
                radioButton.text = symbol
                group.addView(radioButton)
            }
            // Set the first radio button as selected by default
            group.check(binding.stockRadioGroup.getChildAt(0).id)
        }
     }

    }

    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setTitle("Exit App")
            .setMessage("Are you sure you want to exit?")
            .setPositiveButton("Yes") { _, _ ->
                // If the user clicks "Yes", exit the app
                finishAffinity()
                exitProcess(0)
            }
            .setNegativeButton("No", null)
            .show()

    }


    }


