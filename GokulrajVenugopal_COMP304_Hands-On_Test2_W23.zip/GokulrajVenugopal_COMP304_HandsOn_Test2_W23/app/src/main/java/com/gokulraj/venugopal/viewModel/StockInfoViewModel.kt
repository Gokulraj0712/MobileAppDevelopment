package com.gokulraj.venugopal.viewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gokulraj.venugopal.database.StockInfo
import com.gokulraj.venugopal.database.StockInfoDatabase
import com.gokulraj.venugopal.repository.StockInfoRepository
import kotlinx.coroutines.launch

class StockInfoViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: StockInfoRepository


    init {
        val stockInfoDao = StockInfoDatabase.getDatabase(application).stockInfoDao()
        repository = StockInfoRepository(stockInfoDao)
    }

    suspend fun getStockInfo(symbol: String): StockInfo {
        return repository.getStockInfo(symbol)
    }


    suspend fun getSymbol(): List<String>  {
        return repository.getStockSymbol()
    }


    fun insertStockInfo(stockInfo: StockInfo) {
        viewModelScope.launch {
            repository.insertStockInfo(stockInfo)
        }
    }
}
