package com.gokulraj.venugopal.broadcaster

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class StockBroadcastReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {

        Toast.makeText(context, intent.getStringExtra("STOCK_INFO"), Toast.LENGTH_SHORT).show()
    }
}