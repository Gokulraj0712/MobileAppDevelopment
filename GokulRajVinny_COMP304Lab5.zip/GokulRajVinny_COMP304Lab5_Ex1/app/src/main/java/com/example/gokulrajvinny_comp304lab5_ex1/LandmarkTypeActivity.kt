package com.example.gokulrajvinny_comp304lab5_ex1

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gokulrajvinny_comp304lab5_ex1.adapter.LandmarkTypesAdapter
import kotlin.system.exitProcess

class LandmarkTypeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landmark_types)

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view_activity)
        recyclerView.layoutManager = GridLayoutManager(this, 2) // 2 columns in the grid

        val landmarkTypes = listOf(
            "Museums",
            "Stadiums",
            "Zoo",
            "Monuments",
            "Attractions"
        )

        val imageResources = listOf(
            R.drawable.museum,
            R.drawable.stadium,
            R.drawable.zoo,
            R.drawable.monuments,
            R.drawable.attractions
        )

        val adapter = LandmarkTypesAdapter(landmarkTypes, imageResources)
        recyclerView.adapter = adapter

        adapter.setOnItemClickListener(object : LandmarkTypesAdapter.OnItemClickListener {
            override fun onItemClick(position: Int) {
                val selectedLandmarkType = landmarkTypes[position]
                val intent = Intent(this@LandmarkTypeActivity, LandmarkListActivity::class.java)
                intent.putExtra("selectedLandmarkType", selectedLandmarkType)
                startActivity(intent)
            }
        })
    }

    override fun onBackPressed() {
        AlertDialog.Builder(this)
            .setTitle("Exit App")
            .setMessage("Are you sure you want to exit?")
            .setPositiveButton("Yes") { _, _ ->
                // If the user clicks "Yes", exit the app
                finishAffinity()
                exitProcess(0)
            }
            .setNegativeButton("No", null)
            .show()
    }
}