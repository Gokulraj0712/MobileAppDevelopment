package com.example.gokulrajvinny_comp304lab5_ex1.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gokulrajvinny_comp304lab5_ex1.R

class LandmarkTypesAdapter(private val landmarkTypes: List<String>, private val imageResources: List<Int>) :
    RecyclerView.Adapter<LandmarkTypesAdapter.ViewHolder>() {

    private var onItemClickListener: OnItemClickListener? = null

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        onItemClickListener = listener
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val landmarkTypeTextView: TextView = itemView.findViewById(R.id.landmark_name_text_view)
        val landmarkTypeImageView: ImageView = itemView.findViewById(R.id.image_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.landmark_type_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val landmarkType = landmarkTypes[position]
        holder.landmarkTypeTextView.text = landmarkType
        holder.landmarkTypeImageView.setImageResource(imageResources[position])

        holder.itemView.setOnClickListener {
            onItemClickListener?.onItemClick(position)
        }
    }

    override fun getItemCount(): Int {
        return landmarkTypes.size
    }
}