package com.example.gokulrajvinny_comp304lab5_ex1

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gokulrajvinny_comp304lab5_ex1.adapter.LandmarkListAdapter

class LandmarkListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landmark_list)

        val selectedLandmarkType = intent.getStringExtra("selectedLandmarkType")
        val landmarkList = getLandmarkList(selectedLandmarkType)
        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view_landmarks)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = LandmarkListAdapter(landmarkList, object : LandmarkListAdapter.OnItemClickListener {
            override fun onItemClick(landmark: Landmark) {
                val intent = Intent(this@LandmarkListActivity, MapActivity::class.java)
                val bundle = Bundle().apply {
                    putParcelable("selectedLandmark", landmark)
                }
                intent.putExtra("landmarkBundle", bundle)
                startActivity(intent)
            }
        })
    }

    private fun getLandmarkList(selectedLandmarkType: String?): List<Landmark> {
        return when (selectedLandmarkType) {
            "Museums" -> listOf(
                Landmark("Royal Ontario Museum","100 Queens Park, Toronto, ON M5S 2C6",  43.6677097, -79.3947771, R.drawable.museum1),
                Landmark("Gardiner Museum", "111 Queens Park, Toronto, ON M5S 2C7",43.6680973, -79.3953418, R.drawable.museum2),
                Landmark("Textile Museum of Canada","55 Centre Ave, Toronto, ON M5G 2H5", 43.6545096, -79.3889335, R.drawable.museum3)
            )
            "Stadiums" -> listOf(
                Landmark("Scotiabank Arena","40 Bay St., Toronto, ON M5J 2X2", 43.64347, -79.3812876, R.drawable.stadium1),
                Landmark("BMO Field", "170 Princes' Blvd, Toronto, ON M6K 3C3",43.6331741,-79.4208049, R.drawable.stadium2),
                Landmark("Rogers centre","1 Blue Jays Way, Toronto, ON M5V 1J1", 43.6417836,-79.3936284, R.drawable.stadium3)
            )
            "Zoo" -> listOf(
                Landmark("Toronto Zoo","2000 Meadowvale Rd, Toronto, ON M1B 5K7", 43.8206661,-79.1836964, R.drawable.zoo1),
                Landmark("High Park Zoo","1873 Bloor St W, Toronto, ON M6R 2Z3", 43.6427715,-79.4636211, R.drawable.zoo2),
                Landmark("African Lion Safari","1386 Cooper Rd, Cambridge, ON N1R 5S2", 43.3409801,-80.1822886, R.drawable.zoo3)
            )
            "Monuments" -> listOf(
                Landmark("South African War Memorial","360 University Ave, Toronto, ON", 43.6513084,-79.3889963, R.drawable.monument1),
                Landmark("Fort Rouille", "Fort Rouille, Toronto, ON M6K 3C3",43.6306694,-79.4257264, R.drawable.monument2),
                Landmark("Katyń Monument","1575 King St W, Toronto, ON M6K 1J4", 43.6382381,-79.4479353, R.drawable.monument3)
            )
            "Attractions" -> listOf(
                Landmark("CN Tower","290 Bremner Blvd, Toronto, ON M5V 3L9", 43.6425701,-79.3892455, R.drawable.attraction1),
                Landmark("Ripley's Aquarium of Canada","288 Bremner Blvd, Toronto, ON M5V 3L9", 43.6421824,-79.3887909, R.drawable.attraction2),
                Landmark("Casa Loma","1 Austin Terrace, Toronto, ON M5R 1X8", 43.678041,-79.4116326, R.drawable.attraction3)
            )
            else -> emptyList()
        }
    }
}