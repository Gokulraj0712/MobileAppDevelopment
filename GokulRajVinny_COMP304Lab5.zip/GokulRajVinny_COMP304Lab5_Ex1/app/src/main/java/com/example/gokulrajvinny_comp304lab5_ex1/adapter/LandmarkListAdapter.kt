package com.example.gokulrajvinny_comp304lab5_ex1.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.gokulrajvinny_comp304lab5_ex1.Landmark
import com.example.gokulrajvinny_comp304lab5_ex1.MapActivity
import com.example.gokulrajvinny_comp304lab5_ex1.R

class LandmarkListAdapter(
    private val landmarks: List<Landmark>,
    private val listener: OnItemClickListener
) : RecyclerView.Adapter<LandmarkListAdapter.LandmarkViewHolder>() {

    inner class LandmarkViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        private val nameTextView: TextView = itemView.findViewById(R.id.landmark_name_text_view)
        private val locationTextView: TextView = itemView.findViewById(R.id.landmark_address_text_view)
        private val imageView: ImageView = itemView.findViewById(R.id.image_view)

        init {
            itemView.setOnClickListener(this)
        }

        fun bind(landmark: Landmark) {
            nameTextView.text = landmark.name
           locationTextView.text = landmark.address
            imageView.setImageResource(landmark.imageResourceId)
        }

        override fun onClick(v: View?) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                listener.onItemClick(landmarks[position])
            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(landmark: Landmark)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LandmarkViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.landmark_list_item, parent, false)
        return LandmarkViewHolder(view)
    }

    override fun onBindViewHolder(holder: LandmarkViewHolder, position: Int) {
        val landmark = landmarks[position]
        holder.bind(landmark)
    }

    override fun getItemCount(): Int {
        return landmarks.size
    }
}