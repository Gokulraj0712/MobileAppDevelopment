package com.example.gokulrajvinny_comp304lab5_ex1

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.PermissionChecker
import androidx.viewbinding.BuildConfig
import com.example.gokulrajvinny_comp304lab5_ex1.databinding.ActivityMapDisplayBinding
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMapDisplayBinding
    private lateinit var googleMap: GoogleMap
    private lateinit var googleMap2: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapDisplayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val googleApiAvailability = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this)
        Log.e("MapActivity", googleApiAvailability.toString())

        if (googleApiAvailability != ConnectionResult.SUCCESS) {
            if (GoogleApiAvailability.getInstance().isUserResolvableError(googleApiAvailability)) {
                GoogleApiAvailability.getInstance().showErrorDialogFragment(this, 2405, 0)
            }
        }
        val normalMap = supportFragmentManager
            .findFragmentById(R.id.normal_map) as SupportMapFragment
        normalMap.getMapAsync(object : OnMapReadyCallback {
            override fun onMapReady(map: GoogleMap) {
                googleMap = map
                val landmark = intent.getBundleExtra("landmarkBundle")?.getParcelable<Landmark>("selectedLandmark")
                val mapPosition = landmark?.let { LatLng(it.latitude, landmark.longitude) }
                mapPosition?.let { MarkerOptions().position(it) }?.let { googleMap.addMarker(it) }
                mapPosition?.let {
                    CameraPosition(
                        it,
                        15f,
                        0f,
                        0f
                    )
                }?.let {
                    CameraUpdateFactory.newCameraPosition(
                        it
                    )
                }?.let {
                    googleMap.animateCamera(
                        it
                    )
                }
                googleMap.mapType=GoogleMap.MAP_TYPE_NORMAL
            }
        })

        val satMap = supportFragmentManager
            .findFragmentById(R.id.satellite_map) as SupportMapFragment
        satMap.getMapAsync(object : OnMapReadyCallback {
            override fun onMapReady(map2: GoogleMap) {
                googleMap2 = map2
                val landmark = intent.getBundleExtra("landmarkBundle")?.getParcelable<Landmark>("selectedLandmark")
                val mapPosition = landmark?.let { LatLng(it.latitude, landmark.longitude) }
                mapPosition?.let { MarkerOptions().position(it) }?.let { googleMap2.addMarker(it) }
                mapPosition?.let {
                    CameraPosition(
                        it,
                        15f,
                        0f,
                        0f
                    )
                }?.let {
                    CameraUpdateFactory.newCameraPosition(
                        it
                    )
                }?.let {
                    googleMap2.animateCamera(
                        it
                    )
                }
                googleMap2.mapType=GoogleMap.MAP_TYPE_SATELLITE
            }
        })
    }

    override fun onMapReady(p0: GoogleMap) {
        TODO("Not yet implemented")
    }



    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode) {
            101 -> {
                if (grantResults.isNotEmpty()) {
                    if (grantResults[0] == PermissionChecker.PERMISSION_GRANTED) {

                    } else {
                        requestPermissions(arrayOf(android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.ACCESS_FINE_LOCATION), 101)
                    }
                } else {
                    val action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                    val uri = Uri.fromParts(
                        "package",
                        BuildConfig.LIBRARY_PACKAGE_NAME,
                        null
                    )
                    startActivity(Intent(action, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    }

}
